import os
import json
import warnings

warnings.filterwarnings("ignore")

import torch
from torchvision.models import resnet18
import torchvision.transforms as transforms
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from art.estimators.classification import PyTorchClassifier
from art.attacks.evasion import HopSkipJump


def HopSkipJump_attack(image_path, max_iter=100, targeted=False):
    # Load pre-trained ResNet18 model
    model = resnet18(pretrained=True)

    # Move model to GPU if available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # Define preprocessing steps
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])

    original_image = Image.open(image_path).convert('RGB')
    input_image = preprocess(original_image).unsqueeze(0).to(device)

    # Create PyTorch classifier
    classifier = PyTorchClassifier(
        model=model,
        clip_values=(0, 1),
        loss=torch.nn.CrossEntropyLoss(),
        optimizer=torch.optim.Adam(model.parameters(), lr=0.01),
        input_shape=(3, 224, 224),
        nb_classes=1000,
        device_type=device
    )

    # Create HopSkipJump attack instance
    hsja_attack = HopSkipJump(classifier, targeted=targeted, max_iter=max_iter,verbose=True)

    # Generate adversarial example
    adv_image = hsja_attack.generate(x=input_image.cpu().numpy())



    # Move adversarial example to GPU
    adv_image = torch.from_numpy(adv_image).to(device)

    # Predictions
    pred_original = classifier.predict(input_image.cpu().numpy())
    pred_adversarial = classifier.predict(adv_image.cpu().numpy())

    adv_image_pil = Image.fromarray((adv_image.cpu().numpy()[0].transpose(1, 2, 0) * 255).astype(np.uint8))
    adv_image_pil = adv_image_pil.resize(original_image.size)

    # Display images
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.imshow(original_image)
    plt.title("Original Image")
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(adv_image_pil)
    plt.title("Adversarial Image")
    plt.axis('off')
    plt.show()

    # Save adversarial image
    advimg_directory = "./advimg"
    os.makedirs(advimg_directory, exist_ok=True)
    adversarial_filename = f"{os.path.splitext(os.path.basename(image_path))[0]}_HopSkipJump{os.path.splitext(image_path)[1]}"
    adv_image_pil.save(os.path.join(advimg_directory, adversarial_filename))

    # Helper function to get class label
    def get_class(i: int):
        labels_path = "imagenet-simple-labels.json"  # Replace with the actual path
        with open(labels_path, "r") as file:
            imagenet_labels = json.load(file)
        print(f"Class {i}: {imagenet_labels[i]}")
        return f"Class {i}: {imagenet_labels[i]}"

    # Get original and adversarial predictions
    original_class = np.argmax(pred_original, axis=1)
    print("Original Predicted Class:", original_class.item())
    get_class(original_class.item())

    adversarial_class = np.argmax(pred_adversarial, axis=1)
    print("Adversarial Predicted Class:", adversarial_class.item())
    get_class(adversarial_class.item())

    re = "Original Predicted Class:", original_class.item(), '\n',get_class(original_class.item()),'\n',\
            "Adversarial Predicted Class:", adversarial_class.item(), '\n', get_class(adversarial_class.item())
    return re


if __name__ == "__main__":
    # Specify the image path and attack parameters
    image_path = "cat.png"
    iterations = 100  # Adjust as needed
    targeted_attack = False  # Set to True for targeted attack
    HopSkipJump_attack(image_path, max_iter=iterations, targeted=targeted_attack)
