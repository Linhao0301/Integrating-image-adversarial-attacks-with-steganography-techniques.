import os
import warnings

warnings.filterwarnings("ignore")

import torch
from torchvision.models import resnet18
import torchvision.transforms as transforms
from PIL import Image
from art.estimators.classification import PyTorchClassifier
from art.attacks.evasion import CarliniL2Method
import numpy as np
import matplotlib.pyplot as plt


def CW_attack(image_path, confidence=0.0, max_iter=100, targeted=False, target_label=0, use_gpu=True):
    # Check if GPU is available and set device
    if use_gpu and torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    # Load pre-trained ResNet18 model and move it to the GPU if available
    model = resnet18(pretrained=True).to(device)

    # Define preprocessing steps
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])

    original_image = Image.open(image_path).convert('RGB')
    input_image = preprocess(original_image).unsqueeze(0).to(device)

    # Create PyTorch classifier
    classifier = PyTorchClassifier(
        model=model,
        clip_values=(0, 1),
        loss=torch.nn.CrossEntropyLoss(),
        optimizer=torch.optim.Adam(model.parameters(), lr=0.01),
        input_shape=(3, 224, 224),
        nb_classes=1000,
        device_type=device.type,
    )

    # Create C&W attack instance
    cw_attack = CarliniL2Method(classifier, confidence=confidence, targeted=targeted, max_iter=max_iter)

    if targeted:
        adv_image = cw_attack.generate(x=input_image.cpu().numpy(), y=torch.tensor([target_label]).cpu().numpy())
    else:
        adv_image = cw_attack.generate(x=input_image.cpu().numpy())

    # Move the adversarial image back to CPU for visualization
    adv_image = torch.tensor(adv_image).to(device)

    # Predict class labels for original and adversarial images
    pred_original = classifier.predict(input_image.cpu().numpy())
    pred_adversarial = classifier.predict(adv_image.cpu().numpy())

    adv_image_pil = Image.fromarray((adv_image.cpu()[0].numpy().transpose(1, 2, 0) * 255).astype(np.uint8))
    adv_image_pil = adv_image_pil.resize(original_image.size)

    # Display original and adversarial images
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.imshow(original_image)
    plt.title("Original Image")
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(adv_image_pil)
    plt.title("Adversarial Image")
    plt.axis('off')
    plt.show()

    # Save the adversarial image
    advimg_directory = "./advimg"
    os.makedirs(advimg_directory, exist_ok=True)
    adversarial_filename = f"{os.path.splitext(os.path.basename(image_path))[0]}_CW{os.path.splitext(image_path)[1]}"
    adv_image_pil.save(os.path.join(advimg_directory, adversarial_filename))

    import json
    def get_class(i: int):
        labels_path = "imagenet-simple-labels.json"  # Replace with the actual path
        with open(labels_path, "r") as file:
            imagenet_labels = json.load(file)
        print(f"Class {i}: {imagenet_labels[i]}")
        return f"Class {i}: {imagenet_labels[i]}"

    # Get final predicted class for original image
    original_class = np.argmax(pred_original, axis=1)
    print("Original Predicted Class:", original_class.item())
    get_class(original_class.item())

    # Get final predicted class for adversarial image
    adversarial_class = np.argmax(pred_adversarial, axis=1)
    print("Adversarial Predicted Class:", adversarial_class.item())
    get_class(adversarial_class.item())

    re = "Original Predicted Class:", original_class.item(), '\n',get_class(original_class.item()),'\n',\
            "Adversarial Predicted Class:", adversarial_class.item(), '\n', get_class(adversarial_class.item())
    return re


if __name__ == "__main__":
    # Specify the image path and attack parameters
    image_path = "cat.png"
    confidence = 0.0
    targeted = False
    max_iter = 100
    use_gpu = True  # Set to True to use GPU
    CW_attack(image_path, confidence, max_iter, targeted=targeted, use_gpu=use_gpu)
