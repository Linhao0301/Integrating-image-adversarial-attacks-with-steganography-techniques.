import os
import tkinter as tk
from tkinter import filedialog
import warnings
warnings.filterwarnings("ignore")

import tkinter as tk
from tkinter import messagebox

class ImageAttackGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Adversarial Attack Against ResNet18")
        self.root.geometry("600x200")  # 设置初始窗口大小为400x200
        
        self.create_widgets()

    def create_widgets(self):
        # 添加图片选择栏目
        self.image_select_frame = tk.Frame(self.root, padx=10, pady=10)
        self.image_select_frame.pack()

        self.image_select_label = tk.Label(self.image_select_frame, text="1. 选择图片:")
        self.image_select_label.pack(side=tk.LEFT)

        self.select_button = tk.Button(self.image_select_frame, text="选择图片", command=self.select_image)
        self.select_button.pack(side=tk.LEFT)

        self.image_path_label = tk.Label(self.root, text="空")
        self.image_path_label.pack()

        # 添加攻击方式选择栏目
        self.attack_select_frame = tk.Frame(self.root, padx=10, pady=10)
        self.attack_select_frame.pack()

        self.attack_select_label = tk.Label(self.attack_select_frame, text="2. 选择攻击方式:")
        self.attack_select_label.pack(side=tk.LEFT)

        self.attack_options = ['FGSM', 'BIM', 'PGD', 'DeepFool', 'C&W', 'JSMA', 'MIM',
                          'One-Pixel','HopSkipJump','JSMA','SaliencyMap', 'Steganography']
        self.selected_attack = tk.StringVar()
        self.selected_attack.set(self.attack_options[0])

        self.selected_attack_menu = tk.OptionMenu(self.attack_select_frame, self.selected_attack, *self.attack_options)
        self.selected_attack_menu.pack(side=tk.LEFT)

        # 添加确认按钮
        self.confirm_button_frame = tk.Frame(self.root, padx=10, pady=10)
        self.confirm_button_frame.pack()

        self.confirm_button = tk.Button(self.confirm_button_frame, text="确认", command=self.on_attack_selected)
        self.confirm_button.pack()

        # 初始化提示标签
        self.status_label = None

    def on_attack_selected(self):
        attack_type = self.selected_attack.get()
        if not attack_type:
            messagebox.showerror("错误", "请选择一个攻击类型。")
            return

        if hasattr(self, 'image_path') and self.img_path:
            if not os.path.exists(self.img_path):
                messagebox.showerror("错误", "图片地址不存在。")
                return

        # 检查文件扩展名是否为图片格式
        valid_extensions = (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff")
        file_extension = os.path.splitext(self.img_path)[1].lower()
        
        if file_extension not in valid_extensions:
            messagebox.showerror("错误", "请选择一张图片。")
            return
        self.input_attack_params(attack_type)

    def input_attack_params(self, attack_type):
        if attack_type == 'FGSM':# !!! couldn't support target !!!
            self.params_fgsm()
        elif attack_type == 'PGD':
            self.params_pgd()
        elif attack_type == 'BIM':
            self.params_bim()
        elif attack_type == 'DeepFool':# !!! couldn't support target !!!
            self.params_deepfool()
        elif attack_type == 'C&W':# !!! couldn't support target !!!
            self.params_cw()
        elif attack_type == 'JSMA':# !!! couldn't support target !!!
            self.params_jsma()
        elif attack_type == 'MIM':# !!! couldn't support target !!!
            self.params_mim()
        elif attack_type == 'One-Pixel':# !!! couldn't support target !!!
            self.params_one_pixel()
        elif attack_type == 'SaliencyMap':# !!! couldn't support target !!!
            self.params_saliency_map()
        elif attack_type == 'HopSkipJump':# !!! couldn't support target !!!
            self.params_hop_skip_jump()
        elif attack_type == 'Steganography':
            self.params_steganography()


    def select_image(self):
        self.img_path = filedialog.askopenfilename(title="选择图片文件", filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp *.tiff")])
        self.image_path_label.config(text="已选择图片：" + self.img_path)

    def open_parameter_window(self, title, args):
        # 创建一个新窗口用于输入参数
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title(title)
        parameter_window.geometry("300x200")

        # 创建 StringVar 变量并设置默认值
        epsilon_var = tk.StringVar()
        epsilon_var.set(str(args["epsilon"]))

        eps_step_var = tk.StringVar()
        eps_step_var.set(str(args["eps_step"]))

        max_iter_var = tk.StringVar()
        max_iter_var.set(str(args["max_iter"]))

        epsilon_label = tk.Label(parameter_window, text="epsilon:")
        epsilon_label.pack()

        parameter_window.epsilon_entry = tk.Entry(parameter_window, textvariable=epsilon_var)
        parameter_window.epsilon_entry.pack()

        eps_step_label = tk.Label(parameter_window, text="eps_step:")
        eps_step_label.pack()

        parameter_window.eps_step_entry = tk.Entry(parameter_window, textvariable=eps_step_var)
        parameter_window.eps_step_entry.pack()

        max_iter_label = tk.Label(parameter_window, text="max_iter:")
        max_iter_label.pack()

        parameter_window.max_iter_entry = tk.Entry(parameter_window, textvariable=max_iter_var)
        parameter_window.max_iter_entry.pack()

        parameter_window.geometry("300x400")
        parameter_window.targeted_var = tk.BooleanVar()
        parameter_window.target_label_var = tk.StringVar()
        
        def toggle_target_label_entry():
            if parameter_window.targeted_var.get():
                parameter_window.target_label_entry.config(state=tk.NORMAL)
            else:
                parameter_window.target_label_entry.config(state=tk.DISABLED)
        
        targeted_checkbox = tk.Checkbutton(parameter_window, text="有目标攻击", variable=parameter_window.targeted_var, command=toggle_target_label_entry)
        targeted_checkbox.pack()
        
        parameter_window.target_label_entry = tk.Entry(parameter_window, textvariable=parameter_window.target_label_var, state=tk.DISABLED)
        parameter_window.target_label_entry.pack()
        

        return parameter_window


    def params_fgsm(self):
        # 创建一个新窗口用于输入参数
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('FGSM_attack')
        parameter_window.geometry("300x200")

        # 在新窗口中添加参数输入框和确认按钮

        epsilon_var = tk.StringVar()
        epsilon_var.set(str(0.03))

        epsilon_label = tk.Label(parameter_window, text="epsilon:")
        epsilon_label.pack()

        parameter_window.epsilon_entry = tk.Entry(parameter_window, textvariable=epsilon_var)
        parameter_window.epsilon_entry.pack()
        # 显示"正在生成对抗样本中"消息
        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.fgsm_attack(
            parameter_window, float(parameter_window.epsilon_entry.get())
        ))
        confirm_parameter_button.pack()  # 将按钮放置在底部


    def fgsm_attack(self, parameter_window, epsilon):
        # 更新消息
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from FGSM import FGSM_attack
        re = FGSM_attack(self.img_path, epsilon, targeted=False,target_label=0)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))
            parameter_window.update_idletasks()  # 立即刷新窗口


    def params_pgd(self):
        parameter_window = self.open_parameter_window("PGD_attack", args={"epsilon":0.1, "eps_step": 0.009, "max_iter":300})
        # 显示"正在生成对抗样本中"消息
        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.pgd_attack(
            parameter_window, float(parameter_window.epsilon_entry.get()), 
            float(parameter_window.eps_step_entry.get()), int(parameter_window.max_iter_entry.get())
        ))
        confirm_parameter_button.pack()
     

    def pgd_attack(self, parameter_window, epsilon, eps_step, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from PGD import PGD_attack
        re = PGD_attack(self.img_path, epsilon, eps_step, max_iter,
                         targeted=parameter_window.targeted_var.get(),target_label=int(parameter_window.target_label_var.get())if parameter_window.targeted_var.get() else None)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))
        


    def params_bim(self):
        parameter_window = self.open_parameter_window("BIM_attack", args={"epsilon":0.1, "eps_step": 0.009, "max_iter":300})
        # 显示"正在生成对抗样本中"消息
        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.pgd_attack(
            parameter_window, float(parameter_window.epsilon_entry.get()), 
            float(parameter_window.eps_step_entry.get()), int(parameter_window.max_iter_entry.get())
        ))
        confirm_parameter_button.pack()

    def bim_attack(self, parameter_window, epsilon, eps_step, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from BIM import BIM_attack
        re = BIM_attack(self.img_path, epsilon, eps_step, max_iter,
                        targeted=parameter_window.targeted_var.get(),target_label=int(parameter_window.target_label_var.get())if parameter_window.targeted_var.get() else None)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))
        

    def params_deepfool(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('DEEPFOOL')
        parameter_window.geometry("300x200")

        epsilon_var = tk.StringVar()
        epsilon_var.set("0.02")  # 设置初始值

        epsilon_label = tk.Label(parameter_window, text="epsilon:")
        epsilon_label.pack()

        parameter_window.epsilon_entry = tk.Entry(parameter_window, textvariable=epsilon_var)
        parameter_window.epsilon_entry.pack()
        max_iter_var = tk.StringVar()
        max_iter_var.set("100")  # 设置初始值

        max_iter_label = tk.Label(parameter_window, text="max_iter:")
        max_iter_label.pack()

        parameter_window.max_iter_entry = tk.Entry(parameter_window, textvariable=max_iter_var)
        parameter_window.max_iter_entry.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()


        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.deepfool_attack(
            parameter_window, float(parameter_window.epsilon_entry.get()), 
            int(parameter_window.max_iter_entry.get())
        ))
        confirm_parameter_button.pack()

        pass

    def deepfool_attack(self, parameter_window, epsilon, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from DeepFool import DeepFool_attack
        re = DeepFool_attack(self.img_path, epsilon=epsilon, max_iter=max_iter)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))

    def params_cw(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('CW_attack')
        parameter_window.geometry("500x300")

        confidence_var = tk.StringVar()
        confidence_var.set("0.0")  # 设置初始值

        confidence_label = tk.Label(parameter_window, text="confidence:")
        confidence_label.pack()

        parameter_window.confidence_entry = tk.Entry(parameter_window, textvariable=confidence_var)
        parameter_window.confidence_entry.pack()

        max_iter_var = tk.StringVar()
        max_iter_var.set("100")  # 设置初始值

        max_iter_label = tk.Label(parameter_window, text="max_iter:")
        max_iter_label.pack()

        parameter_window.max_iter_entry = tk.Entry(parameter_window, textvariable=max_iter_var)
        parameter_window.max_iter_entry.pack()

        parameter_window.targeted_var = tk.BooleanVar()
        parameter_window.target_label_var = tk.StringVar()
        
        def toggle_target_label_entry():
            if parameter_window.targeted_var.get():
                parameter_window.target_label_entry.config(state=tk.NORMAL)
            else:
                parameter_window.target_label_entry.config(state=tk.DISABLED)
        
        targeted_checkbox = tk.Checkbutton(parameter_window, text="有目标攻击", variable=parameter_window.targeted_var, command=toggle_target_label_entry)
        targeted_checkbox.pack()
        
        parameter_window.target_label_entry = tk.Entry(parameter_window, textvariable=parameter_window.target_label_var, state=tk.DISABLED)
        parameter_window.target_label_entry.pack()

        parameter_window.gpu_used_var = tk.BooleanVar()
        targeted_checkbox = tk.Checkbutton(parameter_window, text="使用gpu", variable=parameter_window.gpu_used_var)
        targeted_checkbox.pack()
        parameter_window.status_label1 = tk.Label(parameter_window, text="该模型速度非常慢，使用GPU也要跑7-10分钟，建议使用GPU")
        parameter_window.status_label1.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.cw_attack(
            parameter_window, float(parameter_window.confidence_entry.get()), int(parameter_window.max_iter_entry.get())
        ))
        confirm_parameter_button.pack()  # 将按钮放置在底部

        pass

    def cw_attack(self, parameter_window, confidence, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from CW import CW_attack
        re = CW_attack(self.img_path, confidence=confidence , max_iter=max_iter, 
                       targeted=parameter_window.targeted_var.get(),
                       target_label=int(parameter_window.target_label_var.get())if parameter_window.targeted_var.get() else None,
                       use_gpu=parameter_window.gpu_used_var.get()
                       )

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))



    def params_jsma(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('JSMA_attack')
        parameter_window.geometry("500x300")

        theta_var = tk.StringVar()
        theta_var.set("0.1")  # 设置初始值

        theta_label = tk.Label(parameter_window, text="theta:")
        theta_label.pack()

        parameter_window.theta_entry = tk.Entry(parameter_window, textvariable=theta_var)
        parameter_window.theta_entry.pack()

        gamma_var = tk.StringVar()
        gamma_var.set("1.0")  # 设置初始值

        gamma_label = tk.Label(parameter_window, text="gamma:")
        gamma_label.pack()

        parameter_window.gamma_entry = tk.Entry(parameter_window, textvariable=gamma_var)
        parameter_window.gamma_entry.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.jsma_attack(
            parameter_window, float(parameter_window.theta_entry.get()), float(parameter_window.gamma_entry.get())
        ))
        confirm_parameter_button.pack()  # 将按钮放置在底部

        pass

    def jsma_attack(self, parameter_window, theta, gamma):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from JSMA import JSMA_attack
        re = JSMA_attack(self.img_path, theta=theta, gamma=gamma)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))


    def params_mim(self):
        parameter_window = self.open_parameter_window("MIM_attack", args={"epsilon":0.1, "eps_step": 0.02, "max_iter":10})

        decay_var = tk.StringVar()
        decay_var.set("1.0")  # 设置初始值

        decay_label = tk.Label(parameter_window, text="decay:")
        decay_label.pack()

        parameter_window.decay_entry = tk.Entry(parameter_window, textvariable=decay_var)
        parameter_window.decay_entry.pack()

        # 显示"正在生成对抗样本中"消息
        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.mim_attack(
            parameter_window, float(parameter_window.epsilon_entry.get()), 
            float(parameter_window.eps_step_entry.get()), float(parameter_window.decay_entry.get()), int(parameter_window.max_iter_entry.get())
        ))
        confirm_parameter_button.pack()
     

    def mim_attack(self, parameter_window, epsilon, eps_step, decay, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from MIM import MIM_attack
        re = MIM_attack(self.img_path, epsilon, eps_step, decay, max_iter,
                         targeted=parameter_window.targeted_var.get(),target_label=int(parameter_window.target_label_var.get())if parameter_window.targeted_var.get() else None)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))

    def params_one_pixel(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('OnePixel_attack')
        parameter_window.geometry("500x300")

        threshold_var = tk.StringVar()
        threshold_var.set("0")  # 设置初始值

        threshold_label = tk.Label(parameter_window, text="threshold:")
        threshold_label.pack()

        parameter_window.threshold_entry = tk.Entry(parameter_window, textvariable=threshold_var)
        parameter_window.threshold_entry.pack()

        es_var = tk.StringVar()
        es_var.set("1")  # 设置初始值

        es_label = tk.Label(parameter_window, text="es:")
        es_label.pack()

        parameter_window.es_entry = tk.Entry(parameter_window, textvariable=es_var)
        parameter_window.es_entry.pack()

        max_iter_var = tk.StringVar()
        max_iter_var.set("100")  # 设置初始值

        max_iter_label = tk.Label(parameter_window, text="max_iter:")
        max_iter_label.pack()

        parameter_window.max_iter_entry = tk.Entry(parameter_window, textvariable=max_iter_var)
        parameter_window.max_iter_entry.pack()

        # 显示"正在生成对抗样本中"消息
        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.one_pixel_attack(
            parameter_window, float(parameter_window.epsilon_entry.get()), 
            float(parameter_window.threshold_entry.get()),
            float(parameter_window.es_entry.get()), int(parameter_window.max_iter_entry.get()))
        )
        confirm_parameter_button.pack()


    def one_pixel_attack(self, parameter_window, threshold, es, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from OnePixel import One_pixel_attack
        re = One_pixel_attack(self.img_path,threshold, es, max_iter,
                            targeted=False)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))

    def params_saliency_map(self):
        pass
    def params_saliency_map(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('Saliency_map_attack')
        parameter_window.geometry("500x300")

        theta_var = tk.StringVar()
        theta_var.set("0.1")  # 设置初始值

        theta_label = tk.Label(parameter_window, text="theta:")
        theta_label.pack()

        parameter_window.theta_entry = tk.Entry(parameter_window, textvariable=theta_var)
        parameter_window.theta_entry.pack()

        gamma_var = tk.StringVar()
        gamma_var.set("0.8")  # 设置初始值

        gamma_label = tk.Label(parameter_window, text="gamma:")
        gamma_label.pack()

        parameter_window.gamma_entry = tk.Entry(parameter_window, textvariable=gamma_var)
        parameter_window.gamma_entry.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.saliency_map_attack(
            parameter_window, float(parameter_window.theta_entry.get()), float(parameter_window.gamma_entry.get())
        ))
        confirm_parameter_button.pack()  # 将按钮放置在底部

        pass

    def saliency_map_attack(self, parameter_window, theta, gamma):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from SaliencyMap import SaliencyMap_attack
        re = SaliencyMap_attack(self.img_path, theta=theta, gamma=gamma)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))


    def params_hop_skip_jump(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('HopSkipJump_attack')
        parameter_window.geometry("300x200")

        max_iter_var = tk.StringVar()
        max_iter_var.set("100")  # 设置初始值

        max_iter_label = tk.Label(parameter_window, text="max_iter:")
        max_iter_label.pack()

        parameter_window.max_iter_entry = tk.Entry(parameter_window, textvariable=max_iter_var)
        parameter_window.max_iter_entry.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.hop_skip_jump_attack(
            parameter_window, float(parameter_window.max_iter_entry.get()))
        )
        confirm_parameter_button.pack()  # 将按钮放置在底部

    def hop_skip_jump_attack(self, parameter_window, max_iter):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from HopSkipJump import HopSkipJump_attack
        re = HopSkipJump_attack(self.img_path, max_iter=max_iter)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功，结果：\n" + ''.join([str(item) for item in re]))

    def params_steganography(self):
        parameter_window = tk.Toplevel(self.root)
        parameter_window.title('HopSkipJump_attack')
        parameter_window.geometry("300x500")

        # 定义变量
        private_key = tk.StringVar()
        private_key.set("Effiel tower")

        public_key = tk.StringVar()
        public_key.set("a tree")

        save_path = tk.StringVar()
        save_path.set("./output")

        num_steps = tk.StringVar()
        num_steps.set("50")

        # 创建标签和输入框
        private_key_label = tk.Label(parameter_window, text="私钥:")
        private_key_label.pack()

        parameter_window.private_key_entry = tk.Entry(parameter_window, textvariable=private_key)
        parameter_window.private_key_entry.pack()

        public_key_label = tk.Label(parameter_window, text="公钥:")
        public_key_label.pack()

        parameter_window.public_key_entry = tk.Entry(parameter_window, textvariable=public_key)
        parameter_window.public_key_entry.pack()

        save_path_label = tk.Label(parameter_window, text="保存路径:")
        save_path_label.pack()

        parameter_window.save_path_entry = tk.Entry(parameter_window, textvariable=save_path)
        parameter_window.save_path_entry.pack()

        num_steps_label = tk.Label(parameter_window, text="步数:")
        num_steps_label.pack()

        parameter_window.num_steps_entry = tk.Entry(parameter_window, textvariable=num_steps)
        parameter_window.num_steps_entry.pack()

        parameter_window.status_label = tk.Label(parameter_window, text="请输入参数")
        parameter_window.status_label.pack()

        confirm_parameter_button = tk.Button(parameter_window, text="确认参数", command=lambda: self.steganography_attack(
            parameter_window, parameter_window.private_key_entry.get(), parameter_window.public_key_entry.get(), 
            parameter_window.num_steps_entry.get())
        )
        confirm_parameter_button.pack()  # 将按钮放置在底部

    def steganography_attack(self, parameter_window, private_key, public_key, num_steps):
        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成中,该模型速度较慢，请耐心等待")
            parameter_window.update_idletasks()  # 立即刷新窗口

        from steganography import process_images
        re = process_images(self.img_path, private_key=private_key, public_key=public_key, save_path='./advimg',num_steps=num_steps)

        if parameter_window.status_label:
            parameter_window.status_label.config(text="对抗样本生成成功")

        


if __name__ == "__main__":
    root = tk.Tk()
    app = ImageAttackGUI(root)
    root.mainloop()
