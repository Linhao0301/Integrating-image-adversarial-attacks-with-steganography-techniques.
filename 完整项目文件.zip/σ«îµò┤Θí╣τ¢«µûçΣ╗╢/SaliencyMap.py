import os
import json
import warnings

warnings.filterwarnings("ignore")

import torch
from torchvision.models import resnet18
import torchvision.transforms as transforms
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from art.estimators.classification import PyTorchClassifier
from art.attacks.evasion import SaliencyMapMethod


def SaliencyMap_attack(image_path, theta=0.1, gamma=0.8):
    # Load the pre-trained ResNet18 model
    model = resnet18(pretrained=True)

    # Define the preprocessing steps
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        # transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    original_image = Image.open(image_path).convert('RGB')
    input_image = preprocess(original_image).unsqueeze(0)

    # Create a PyTorch classifier
    classifier = PyTorchClassifier(
        model=model,
        clip_values=(0, 1),
        loss=torch.nn.CrossEntropyLoss(),
        optimizer=torch.optim.Adam(model.parameters(), lr=0.01),
        input_shape=(3, 224, 224),
        nb_classes=1000,
    )

    # Predict the class of the original image
    pred_original = classifier.predict(input_image.numpy())

    # Print the original predicted class and label
    original_class = np.argmax(pred_original, axis=1)
    print("Original Predicted Class:", original_class.item())
    get_class(original_class.item())

    # Create Saliency Map attack instance
    saliency_map_attack = SaliencyMapMethod(classifier, theta=theta, gamma=gamma)

    # Generate adversarial image using Saliency Map attack
    adv_image = saliency_map_attack.generate(x=input_image.numpy())

    # Predict the class of the adversarial image
    pred_adversarial = classifier.predict(adv_image)

    adv_image_pil = Image.fromarray((adv_image[0].transpose(1, 2, 0) * 255).astype(np.uint8))
    adv_image_pil = adv_image_pil.resize(original_image.size)

    # Display the original image, original predicted class, and Saliency Map adversarial image
    plt.figure(figsize=(18, 6))

    plt.subplot(1, 3, 1)
    plt.imshow(original_image)
    plt.title("Original Image")
    plt.axis('off')

    plt.subplot(1, 3, 2)
    plt.imshow(adv_image_pil)
    plt.title("Saliency Map Adversarial Image")
    plt.axis('off')

    plt.subplot(1, 3, 3)
    plt.bar(range(1000), pred_original[0])
    plt.title("Original Prediction")
    plt.xlabel("Class Index")
    plt.ylabel("Prediction Score")

    plt.show()

    # Save the Saliency Map adversarial image
    advimg_directory = "./advimg"
    os.makedirs(advimg_directory, exist_ok=True)
    adversarial_filename = f"{os.path.splitext(os.path.basename(image_path))[0]}_SaliencyMap{os.path.splitext(image_path)[1]}"
    adv_image_pil.save(os.path.join(advimg_directory, adversarial_filename))

    # Print the Saliency Map adversarial predicted class and label
    adversarial_class = np.argmax(pred_adversarial, axis=1)
    print("Saliency Map Adversarial Predicted Class:", adversarial_class.item())
    get_class(adversarial_class.item())

    re = "Original Predicted Class:", original_class.item(), '\n',get_class(original_class.item()),'\n',\
            "Adversarial Predicted Class:", adversarial_class.item(), '\n', get_class(adversarial_class.item())
    return re


def get_class(i: int):
    labels_path = "imagenet-simple-labels.json" 
    with open(labels_path, "r") as file:
        imagenet_labels = json.load(file)
    print(f"Class {i}: {imagenet_labels[i]}")
    return f"Class {i}: {imagenet_labels[i]}"


if __name__ == "__main__":
    # Specify the image path and Saliency Map attack parameters
    image_path = "cat.png"
    theta_param = 0.1
    gamma_param = 0.8
    SaliencyMap_attack(image_path, theta_param, gamma_param)
