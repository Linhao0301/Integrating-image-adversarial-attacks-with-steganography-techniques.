import os
import warnings
warnings.filterwarnings("ignore")

import torch
from torchvision.models import resnet18
import torchvision.transforms as transforms
from PIL import Image
from art.estimators.classification import PyTorchClassifier
from art.attacks.evasion import SaliencyMapMethod
import numpy as np
import matplotlib.pyplot as plt

def JSMA_attack(image_path, theta=0.1, gamma=1.0):
    # Load pre-trained ResNet18 model
    model = resnet18(pretrained=True)

    # Define preprocessing steps
    preprocess = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
    ])

    original_image = Image.open(image_path).convert('RGB')
    input_image = preprocess(original_image).unsqueeze(0)

    # Create PyTorch classifier
    classifier = PyTorchClassifier(
        model=model,
        clip_values=(0, 1),
        loss=torch.nn.CrossEntropyLoss(),
        optimizer=torch.optim.Adam(model.parameters(), lr=0.01),
        input_shape=(3, 224, 224),
        nb_classes=1000,
    )

    # Create JSMA attack instance
    jsma_attack = SaliencyMapMethod(classifier, theta=theta, gamma=gamma)

    # Generate adversarial image
    adv_image = jsma_attack.generate(x=input_image.numpy())

    # Predict class labels for original and adversarial images
    pred_original = classifier.predict(input_image.numpy())
    pred_adversarial = classifier.predict(adv_image)

    adv_image_pil = Image.fromarray((adv_image[0].transpose(1, 2, 0) * 255).astype(np.uint8))
    adv_image_pil = adv_image_pil.resize(original_image.size)

    # Display original and adversarial images
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.imshow(original_image)
    plt.title("Original Image")
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(adv_image_pil)
    plt.title("Adversarial Image")
    plt.axis('off')
    plt.show()

    # Save the adversarial image
    advimg_directory = "./advimg"
    os.makedirs(advimg_directory, exist_ok=True)
    adversarial_filename = f"{os.path.splitext(os.path.basename(image_path))[0]}_JSMA{os.path.splitext(image_path)[1]}"
    adv_image_pil.save(os.path.join(advimg_directory, adversarial_filename))

    import json
    def get_class(i:int):
        labels_path = "imagenet-simple-labels.json"  # Replace with the actual path
        with open(labels_path, "r") as file:
            imagenet_labels = json.load(file)
        print(f"Class {i}: {imagenet_labels[i]}")
        return f"Class {i}: {imagenet_labels[i]}"

    # Get final predicted class for original image
    original_class = np.argmax(pred_original, axis=1)
    print("Original Predicted Class:", original_class.item())
    get_class(original_class.item())

    # Get final predicted class for adversarial image
    adversarial_class = np.argmax(pred_adversarial, axis=1)
    print("Adversarial Predicted Class:", adversarial_class.item())
    get_class(adversarial_class.item())

    re = "Original Predicted Class:", original_class.item(), '\n',get_class(original_class.item()),'\n',\
            "Adversarial Predicted Class:", adversarial_class.item(), '\n', get_class(adversarial_class.item())
    return re

if __name__ == "__main__":
    # Specify the image path and attack parameters
    image_path = "cat.png"
    theta = 0.1
    gamma = 1.0
    JSMA_attack(image_path, theta, gamma)
